// Category editor JS

(function () {
  var editor9 = new Quill("#editor9", {
    modules: { toolbar: "#toolbar9" },
    theme: "snow",
    placeholder: "Enter your messages...",
  });
  var editor10 = new Quill("#editor10", {
    modules: { toolbar: "#toolbar10" },
    theme: "snow",
    placeholder: "Enter your messages...",
  });
})();
