(function () {
  feather.replace();
})();
