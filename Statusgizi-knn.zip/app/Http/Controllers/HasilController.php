<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HasilController
{
    public function hasil()
    {
        return view('user.hasil');
    }
}
